<div class="site-main-container">

  <!-- Start latest-post Area -->
  <section class="latest-post-area pb-120">
    <div class="container no-padding">
      <div class="row">
        <div class="col-lg-12 post-list">
          <!-- Start single-post Area -->
          <div class="single-post-wrap">

            <div class="content-wrap">

              <a>
                <h3>Privacy Policy</h3>
              </a>
              <br>

              <p><?php echo nl2br($privacy); ?></p>


          </div>

        </div>
        <!-- End single-post Area -->
      </div>

    </div>
  </div>
</section>
<!-- End latest-post Area -->
</div>
