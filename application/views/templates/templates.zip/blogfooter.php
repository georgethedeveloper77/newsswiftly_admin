<!-- start footer Area -->
<footer class="footer-area">
  <div class="container" style="padding:0px 0px 0px 15px;">

    <div class="footer-bottom row align-items-center">
      <p class="footer-text m-0 col-lg-8 col-md-12"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
       Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved <a href="<?php echo site_url(); ?>" target="_blank">NewsExtra</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
      <div class="col-lg-4 col-md-12 footer-social">
        <a href="<?php echo $this->session->userdata ( 'facebook_page_url' ); ?>"><i class="fa fa-facebook"></i></a>
        <a href="<?php echo $this->session->userdata ( 'twitter_page_url' ); ?>"><i class="fa fa-twitter"></i></a>
      </div>
    </div>
  </div>
</footer>
<!-- End footer Area -->
<script src="<?php echo asset_url('js/vendor/jquery-2.2.4.min.js'); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="<?php echo asset_url('js/vendor/bootstrap.min.js'); ?>"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
<script src="<?php echo asset_url('js/easing.min.js'); ?>"></script>
<script src="<?php echo asset_url('js/hoverIntent.js'); ?>"></script>
<script src="<?php echo asset_url('js/superfish.min.js'); ?>"></script>
<script src="<?php echo asset_url('js/jquery.ajaxchimp.min.js'); ?>"></script>
<script src="<?php echo asset_url('js/jquery.magnific-popup.min.js'); ?>"></script>
<script src="<?php echo asset_url('js/mn-accordion.js'); ?>"></script>
<script src="<?php echo asset_url('js/jquery-ui.js'); ?>"></script>
<script src="<?php echo asset_url('js/jquery.nice-select.min.js'); ?>"></script>
<script src="<?php echo asset_url('js/owl.carousel.min.js'); ?>"></script>
<script src="<?php echo asset_url('js/mail-script.js'); ?>"></script>
<script src="<?php echo asset_url('js/main.js'); ?>"></script>

</body>
</html>
